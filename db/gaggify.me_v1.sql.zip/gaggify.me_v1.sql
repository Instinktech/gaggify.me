-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2013 at 06:24 PM
-- Server version: 5.5.25
-- PHP Version: 5.3.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gaggify.me_v1`
--

-- --------------------------------------------------------

--
-- Table structure for table `analy_pagehits`
--

CREATE TABLE `analy_pagehits` (
  `gag_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `referer` text,
  `utm_src` text,
  `utm_cookie` varchar(100) DEFAULT NULL,
  `utm_inat` varchar(20) NOT NULL,
  `utm_outat` varchar(20) DEFAULT NULL,
  `utm_addr` varchar(20) NOT NULL,
  `utm_agent` varchar(100) DEFAULT NULL,
  `hit_on` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gags`
--

CREATE TABLE `gags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `img_original` varchar(64) NOT NULL,
  `img_100x100` varchar(64) DEFAULT NULL,
  `img_250x250` varchar(64) DEFAULT NULL,
  `img_640x800` varchar(64) DEFAULT NULL,
  `mime` varchar(20) DEFAULT NULL,
  `likes` int(11) NOT NULL DEFAULT '0',
  `dislikes` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `uploaded_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `host_ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `stickies`
--

CREATE TABLE `stickies` (
  `sticky_id` int(11) NOT NULL AUTO_INCREMENT,
  `gag_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sticked_on` varchar(20) NOT NULL,
  PRIMARY KEY (`sticky_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `is_verified` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `locale` varchar(30) NOT NULL,
  `created_on` varchar(20) DEFAULT NULL,
  `host_ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fb_id`, `username`, `is_verified`, `email`, `locale`, `created_on`, `host_ip`) VALUES
(1, 2147483647, 'hamza.waqas.125', 1, 'hamzawaqas@ftml.net', 'en_US', '1371560366', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `id` int(11) DEFAULT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `birthday` varchar(30) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `created_on` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `first_name`, `last_name`, `birthday`, `location`, `website`, `gender`, `created_on`) VALUES
(1, 'Hamza', 'Waqas', '11/01/1992', 'Karachi, Pakistan', 'www.hamzawaqas.me', 'male', '1371560366');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
